import java.util.*;

import jdk.nashorn.api.tree.ForInLoopTree;

public class PocetCisel {

    public static int pocet =0;
    
    public static void main(String[] args) {

        int pocet =0;
        int co=0;

        Scanner sc = new Scanner(System.in);
        Random rn=new Random();
        System.out.println("Jak chcete velké pole?");
        int vel = sc.nextInt();
        int[] row =new int[vel];

        for (int i = 0; i < row.length; i++) {
            row[i]=rn.nextInt(9);
        }
        
        for (int j= 0; j < row.length; j++) {
                    System.out.print(row[j]+", ");
               }

        System.out.println("Co chcete spočítat?");
            co = sc.nextInt();


            for (int i = 0; i < row.length; i++) {
                if(row[i]==co){
                    pocet++;
                }

                

                
            }
            
            
            System.out.println("Čísel s hodnotou "+co+"je v poli "+pocet);
    }
    
}
