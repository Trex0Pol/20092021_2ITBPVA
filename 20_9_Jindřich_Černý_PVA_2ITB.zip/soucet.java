import java.util.*;

public class soucet {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        Random rn=new Random();
        
        
        System.out.println("Jak chcete velké pole?");
        int vel = sc.nextInt();
        int[] row =new int[vel];

        for (int i = 0; i < row.length; i++) {
            row[i]=rn.nextInt(9);
        }

        for (int j= 0; j < row.length; j++) {
            System.out.print(row[j]+", ");
       }

        int sum =0;
        for (int i = 0; i < row.length; i++) {
            sum+=row[i];
        }

        System.out.println("Součet je "+sum);
    }
}
